package datalayer;

public interface FindingCategoryDAO {
	int getCategoryIdForCategoryName(String categoryName);
}
